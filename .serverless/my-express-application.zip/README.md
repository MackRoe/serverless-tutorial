# Serverless Tutorial

found at:<br>

https://www.serverless.com/blog/serverless-express-rest-api
<p>
Service Information<br>
service: my-express-application<br>
stage: dev<br>
region: us-east-1<br>
stack: my-express-application-dev<br>
resources: 12<br>
api keys:<br>
  None<br>
endpoints:<br>
  ANY - https://h7spcrwcid.execute-api.us-east-1.amazonaws.com/dev<br>
  ANY - https://h7spcrwcid.execute-api.us-east-1.amazonaws.com/dev/{proxy+}<br>
functions:<br>
  app: my-express-application-dev-app<br>
layers:<br>
  None
